﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CookieSourceGTG
{
    public partial class OrderDisplayForm : Form
    {
        public OrderDisplayForm()
        {
            InitializeComponent();
        }

        private void OrderDisplayForm_Load(object sender, EventArgs e)
        {
            List<Order> cookiesSorted = new List<Order>(OrderEntryForm.cOrderList);
            cookiesSorted.Sort();

            foreach (var item in cookiesSorted)
            {
               lblDisplay.Text = item.ToString();
            }
        }

        private void btnOrderEntry_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
