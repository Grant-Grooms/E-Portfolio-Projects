﻿namespace CookieSourceGTG
{
    partial class OrderEntryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.txtPhoneNum = new System.Windows.Forms.TextBox();
            this.rdbChocChip = new System.Windows.Forms.RadioButton();
            this.rdbOat = new System.Windows.Forms.RadioButton();
            this.rdbSugar = new System.Windows.Forms.RadioButton();
            this.dtpDeliveryDate = new System.Windows.Forms.DateTimePicker();
            this.cmbQty = new System.Windows.Forms.ComboBox();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.btnAddOrder = new System.Windows.Forms.Button();
            this.tbxOrderQueue = new System.Windows.Forms.TextBox();
            this.lblCustName = new System.Windows.Forms.Label();
            this.lblPhoneNum = new System.Windows.Forms.Label();
            this.lblQty = new System.Windows.Forms.Label();
            this.lblDDate = new System.Windows.Forms.Label();
            this.lblOrderQueue = new System.Windows.Forms.Label();
            this.gbxCookies = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.gbxCookies.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCustName
            // 
            this.txtCustName.Location = new System.Drawing.Point(96, 22);
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.Size = new System.Drawing.Size(100, 20);
            this.txtCustName.TabIndex = 0;
            // 
            // txtPhoneNum
            // 
            this.txtPhoneNum.Location = new System.Drawing.Point(96, 62);
            this.txtPhoneNum.Name = "txtPhoneNum";
            this.txtPhoneNum.Size = new System.Drawing.Size(100, 20);
            this.txtPhoneNum.TabIndex = 1;
            // 
            // rdbChocChip
            // 
            this.rdbChocChip.AutoSize = true;
            this.rdbChocChip.Location = new System.Drawing.Point(25, 12);
            this.rdbChocChip.Name = "rdbChocChip";
            this.rdbChocChip.Size = new System.Drawing.Size(97, 17);
            this.rdbChocChip.TabIndex = 2;
            this.rdbChocChip.TabStop = true;
            this.rdbChocChip.Text = "Chocolate Chip";
            this.rdbChocChip.UseVisualStyleBackColor = true;
            this.rdbChocChip.CheckedChanged += new System.EventHandler(this.rdbChocChip_CheckedChanged);
            // 
            // rdbOat
            // 
            this.rdbOat.AutoSize = true;
            this.rdbOat.Location = new System.Drawing.Point(25, 50);
            this.rdbOat.Name = "rdbOat";
            this.rdbOat.Size = new System.Drawing.Size(64, 17);
            this.rdbOat.TabIndex = 3;
            this.rdbOat.TabStop = true;
            this.rdbOat.Text = "Oatmeal";
            this.rdbOat.UseVisualStyleBackColor = true;
            this.rdbOat.CheckedChanged += new System.EventHandler(this.rdbOat_CheckedChanged);
            // 
            // rdbSugar
            // 
            this.rdbSugar.AutoSize = true;
            this.rdbSugar.Location = new System.Drawing.Point(25, 87);
            this.rdbSugar.Name = "rdbSugar";
            this.rdbSugar.Size = new System.Drawing.Size(53, 17);
            this.rdbSugar.TabIndex = 4;
            this.rdbSugar.TabStop = true;
            this.rdbSugar.Text = "Sugar";
            this.rdbSugar.UseVisualStyleBackColor = true;
            this.rdbSugar.CheckedChanged += new System.EventHandler(this.rdbSugar_CheckedChanged);
            // 
            // dtpDeliveryDate
            // 
            this.dtpDeliveryDate.Location = new System.Drawing.Point(72, 244);
            this.dtpDeliveryDate.Name = "dtpDeliveryDate";
            this.dtpDeliveryDate.Size = new System.Drawing.Size(200, 20);
            this.dtpDeliveryDate.TabIndex = 5;
            // 
            // cmbQty
            // 
            this.cmbQty.FormattingEnabled = true;
            this.cmbQty.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.cmbQty.Location = new System.Drawing.Point(96, 205);
            this.cmbQty.Name = "cmbQty";
            this.cmbQty.Size = new System.Drawing.Size(121, 21);
            this.cmbQty.TabIndex = 6;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(636, 276);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(97, 23);
            this.btnDisplay.TabIndex = 8;
            this.btnDisplay.Text = "Display Orders";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // btnAddOrder
            // 
            this.btnAddOrder.Location = new System.Drawing.Point(555, 276);
            this.btnAddOrder.Name = "btnAddOrder";
            this.btnAddOrder.Size = new System.Drawing.Size(75, 23);
            this.btnAddOrder.TabIndex = 9;
            this.btnAddOrder.Text = "Add Order";
            this.btnAddOrder.UseVisualStyleBackColor = true;
            this.btnAddOrder.Click += new System.EventHandler(this.btnAddOrder_Click);
            // 
            // tbxOrderQueue
            // 
            this.tbxOrderQueue.Location = new System.Drawing.Point(489, 61);
            this.tbxOrderQueue.Multiline = true;
            this.tbxOrderQueue.Name = "tbxOrderQueue";
            this.tbxOrderQueue.Size = new System.Drawing.Size(244, 202);
            this.tbxOrderQueue.TabIndex = 10;
            // 
            // lblCustName
            // 
            this.lblCustName.AutoSize = true;
            this.lblCustName.Location = new System.Drawing.Point(31, 25);
            this.lblCustName.Name = "lblCustName";
            this.lblCustName.Size = new System.Drawing.Size(38, 13);
            this.lblCustName.TabIndex = 11;
            this.lblCustName.Text = "Name:";
            // 
            // lblPhoneNum
            // 
            this.lblPhoneNum.AutoSize = true;
            this.lblPhoneNum.Location = new System.Drawing.Point(21, 65);
            this.lblPhoneNum.Name = "lblPhoneNum";
            this.lblPhoneNum.Size = new System.Drawing.Size(51, 13);
            this.lblPhoneNum.TabIndex = 12;
            this.lblPhoneNum.Text = "Phone #:";
            // 
            // lblQty
            // 
            this.lblQty.AutoSize = true;
            this.lblQty.Location = new System.Drawing.Point(-2, 208);
            this.lblQty.Name = "lblQty";
            this.lblQty.Size = new System.Drawing.Size(92, 13);
            this.lblQty.TabIndex = 13;
            this.lblQty.Text = "Quantity (dozens):";
            // 
            // lblDDate
            // 
            this.lblDDate.AutoSize = true;
            this.lblDDate.Location = new System.Drawing.Point(-2, 250);
            this.lblDDate.Name = "lblDDate";
            this.lblDDate.Size = new System.Drawing.Size(74, 13);
            this.lblDDate.TabIndex = 14;
            this.lblDDate.Text = "Delivery Date:";
            // 
            // lblOrderQueue
            // 
            this.lblOrderQueue.AutoSize = true;
            this.lblOrderQueue.Location = new System.Drawing.Point(486, 45);
            this.lblOrderQueue.Name = "lblOrderQueue";
            this.lblOrderQueue.Size = new System.Drawing.Size(79, 13);
            this.lblOrderQueue.TabIndex = 15;
            this.lblOrderQueue.Text = "Queued Orders";
            // 
            // gbxCookies
            // 
            this.gbxCookies.Controls.Add(this.rdbOat);
            this.gbxCookies.Controls.Add(this.rdbChocChip);
            this.gbxCookies.Controls.Add(this.rdbSugar);
            this.gbxCookies.Location = new System.Drawing.Point(24, 88);
            this.gbxCookies.Name = "gbxCookies";
            this.gbxCookies.Size = new System.Drawing.Size(200, 110);
            this.gbxCookies.TabIndex = 16;
            this.gbxCookies.TabStop = false;
            this.gbxCookies.Text = "Cookies";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(474, 276);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 17;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // OrderEntryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.gbxCookies);
            this.Controls.Add(this.lblOrderQueue);
            this.Controls.Add(this.lblDDate);
            this.Controls.Add(this.lblQty);
            this.Controls.Add(this.lblPhoneNum);
            this.Controls.Add(this.lblCustName);
            this.Controls.Add(this.tbxOrderQueue);
            this.Controls.Add(this.btnAddOrder);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.cmbQty);
            this.Controls.Add(this.dtpDeliveryDate);
            this.Controls.Add(this.txtPhoneNum);
            this.Controls.Add(this.txtCustName);
            this.Name = "OrderEntryForm";
            this.Text = "Order Entry";
            this.Load += new System.EventHandler(this.OrderEntryForm_Load);
            this.gbxCookies.ResumeLayout(false);
            this.gbxCookies.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.TextBox txtPhoneNum;
        private System.Windows.Forms.RadioButton rdbChocChip;
        private System.Windows.Forms.RadioButton rdbOat;
        private System.Windows.Forms.RadioButton rdbSugar;
        private System.Windows.Forms.DateTimePicker dtpDeliveryDate;
        private System.Windows.Forms.ComboBox cmbQty;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Button btnAddOrder;
        private System.Windows.Forms.TextBox tbxOrderQueue;
        private System.Windows.Forms.Label lblCustName;
        private System.Windows.Forms.Label lblPhoneNum;
        private System.Windows.Forms.Label lblQty;
        private System.Windows.Forms.Label lblDDate;
        private System.Windows.Forms.Label lblOrderQueue;
        private System.Windows.Forms.GroupBox gbxCookies;
        private System.Windows.Forms.Button btnExit;
    }
}

