﻿namespace CookieSourceGTG
{
    partial class OrderDisplayForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOrderEntry = new System.Windows.Forms.Button();
            this.lblDisplay = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnOrderEntry
            // 
            this.btnOrderEntry.Location = new System.Drawing.Point(345, 248);
            this.btnOrderEntry.Name = "btnOrderEntry";
            this.btnOrderEntry.Size = new System.Drawing.Size(75, 23);
            this.btnOrderEntry.TabIndex = 1;
            this.btnOrderEntry.Text = "Order Entry";
            this.btnOrderEntry.UseVisualStyleBackColor = true;
            this.btnOrderEntry.Click += new System.EventHandler(this.btnOrderEntry_Click);
            // 
            // lblDisplay
            // 
            this.lblDisplay.AutoSize = true;
            this.lblDisplay.Location = new System.Drawing.Point(36, 63);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(0, 13);
            this.lblDisplay.TabIndex = 0;
            // 
            // OrderDisplayForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnOrderEntry);
            this.Controls.Add(this.lblDisplay);
            this.Name = "OrderDisplayForm";
            this.Text = "OrderDisplayForm";
            this.Load += new System.EventHandler(this.OrderDisplayForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnOrderEntry;
        private System.Windows.Forms.Label lblDisplay;
    }
}