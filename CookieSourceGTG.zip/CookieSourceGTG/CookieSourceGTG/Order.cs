﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    [Serializable]
    public class Order : IComparable<Order>
    {
        public static string custName;
        public static string phoneNum;
        public static string cookieType;
        public static string qty;
        public static DateTime cDate;
        public static DateTime dDate;

        public string CustName
        {
            get
            {
                return custName;
            }
            set
            {
                if (value.Equals(""))
                {
                    BlankNameException bne = new BlankNameException();
                    throw(bne);
                }
                custName = value;
            }
        }
        public string PhoneNum
        {
            get
            {
                return phoneNum;
            }
            set
            {
                phoneNum = value;
            }
        }
        public string CookieType
        {
            get
            {
                return cookieType;
            }
            set
            {
                cookieType = value;
            }
        }
        public string Qty
        {
            get
            {
                return qty;
            }
            set
            {
                qty = value;
            }
        }
        public DateTime CDate
        {
            get
            {
                return cDate;
            }
            set
            {
                cDate = value;
            }
        }
        public DateTime DDate
        {
            get
            {
                return dDate;
            }
            set
            {
                dDate = value;
            }
        }
        public Order()
        {
            CustName = "Joe Smith";
            PhoneNum = "555-555-5555";
            CookieType = "Chocolate Chip";
            Qty = "1";
            CDate = DateTime.Now;
            DDate = DateTime.MaxValue;
        }
        public Order(string name, string phone, string cookies, string quantity, DateTime orderDate, DateTime delivery)
        {
            CustName = name;
            PhoneNum = phone;
            CookieType = cookies;
            Qty = quantity;
            CDate = orderDate;
            DDate = delivery;
        }
        public override string ToString()
        {
            return "Customer name: " + custName + "\n" + "Phone number: " + phoneNum + "\n" + "Cookie type: " + cookieType + "\n" + "Quantity: " + qty + "\n" + "Order date: " + cDate + "\n" + "Delivery date: " + dDate;
        }
        public int CompareTo(Order compOrder)
        {
            return this.DDate.CompareTo(compOrder.DDate);
        }
        class BlankNameException : Exception
        {
            private static string errMsg = "Name not entered";
            public BlankNameException() : base(errMsg)
            {

            }
        }
    }
