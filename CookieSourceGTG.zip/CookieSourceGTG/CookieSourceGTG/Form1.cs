﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CookieSourceGTG
{
    public partial class OrderEntryForm : Form
    {
        public static List<Order> cOrderList = new List<Order>();
        public static string cookieString;
        public static int newOrderCtr = 0;

        public OrderEntryForm()
        {
            InitializeComponent();
        }

        private void OrderEntryForm_Load(object sender, EventArgs e)
        {
            dtpDeliveryDate.MinDate = DateTime.Now;
            if (File.Exists("Cookie_Orders.ser"))
            {
                FileStream input = new FileStream("Cookie_Orders.ser", FileMode.Open, FileAccess.Read);
                BinaryFormatter inputFormatter = new BinaryFormatter();

                while (input.Position < input.Length)
                {
                    Order order = (Order)inputFormatter.Deserialize(input);
                    cOrderList.Add(order);
                }
            }
        }


        private void btnDisplay_Click(object sender, EventArgs e)
        {
            OrderDisplayForm orderDisplay = new OrderDisplayForm();
            orderDisplay.ShowDialog();
        }

        private void btnAddOrder_Click(object sender, EventArgs e)
        {
            Order newOrder = new Order(txtCustName.Text, txtPhoneNum.Text, cookieString, cmbQty.Text, DateTime.Now, dtpDeliveryDate.Value);
            cOrderList.Add(newOrder);
            newOrderCtr++;
            if (newOrderCtr == 1)
            {
               tbxOrderQueue.Text = newOrder.CustName + Environment.NewLine + newOrder.PhoneNum + Environment.NewLine + newOrder.CookieType + Environment.NewLine +
               newOrder.Qty + Environment.NewLine + newOrder.CDate.ToShortDateString() + Environment.NewLine + newOrder.DDate.ToShortDateString() + Environment.NewLine;
            }
            else
            {
               tbxOrderQueue.AppendText(tbxOrderQueue.Text = newOrder.CustName + Environment.NewLine + newOrder.PhoneNum + Environment.NewLine + newOrder.CookieType + Environment.NewLine +
               newOrder.Qty + Environment.NewLine + newOrder.CDate.ToShortDateString() + Environment.NewLine + newOrder.DDate.ToShortDateString() + Environment.NewLine);
            }
        }

        private void rdbChocChip_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbChocChip.Checked == true)
            {
                cookieString = "Chocolate Chip";
            }
        }

        private void rdbOat_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbOat.Checked == true)
            {
                cookieString = "Oatmeal";
            }
        }

        private void rdbSugar_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbSugar.Checked == true)
            {
                cookieString = "Sugar";
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            FileStream outFile = new FileStream("Cookie_Orders.ser",
                       FileMode.Create, FileAccess.Write);
            BinaryFormatter orderFormatter = new BinaryFormatter();

            foreach (var item in cOrderList)
            {
                orderFormatter.Serialize(outFile, item);
            }
            outFile.Close();
        }
    }
}
