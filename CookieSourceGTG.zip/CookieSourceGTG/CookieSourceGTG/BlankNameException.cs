﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CookieSourceGTG
{
    public class BlankNameException: Exception
    {
        private static string errMsg = "Name not entered";
        public BlankNameException(): base(errMsg)
        {

        }
    }
}
