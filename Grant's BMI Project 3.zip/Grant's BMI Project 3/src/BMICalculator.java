
public class BMICalculator {
	
}
